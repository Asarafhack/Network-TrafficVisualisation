# network_traffic_analysis_tool.py

# ANSI escape codes for color
RED = '\033[91m'
GREEN = '\033[92m'
RESET = '\033[0m'

# Devil Net-Analyser banner with red and green theme
BANNER = f"""
{RED}  ____            _      _ _            _     _  _                 
 |  _ \\ ___  _ __ | | ___| | | ___   ___ | |_  | || |_   ___  _ __  
 | |_) / _ \\| '_ \\| |/ _ \\ | |/ _ \\ / _ \\| __| | || __| / _ \\| '_ \\ 
 |  __/ (_) | | | | |  __/ | | (_) | (_) | |_  | || |_ |  __/| | | |
 |_|   \\___/|_| |_|_|\\___|_|_|\\___/ \\___/ \\__|  \\__\\/__| \\___/|_| |_|
{RESET}
{GREEN}Welcome to the  ASARAF Devil Net-Analyser
{RESET}
"""

import scapy.all as scapy
import matplotlib.pyplot as plt
from collections import Counter
import os
import csv
import datetime
import sys

def display_banner():
    os.system('cls' if os.name == 'nt' else 'clear')  # Clear terminal screen
    print(BANNER)

def is_root():
    return os.geteuid() == 0

def select_interface():
    print("Select Interface Type:")
    print("1. Ethernet (eth0)")
    print("2. Wireless (wlan0)")
    print("3. FTP (ftp)")
    print("4. Exit")
    choice = input("Enter your choice (1/2/3/4): ")
    if choice == '1':
        return 'eth0'
    elif choice == '2':
        return 'wlan0'
    elif choice == '3':
        return 'ftp'
    elif choice == '4':
        print("Exiting...")
        sys.exit(0)
    else:
        print("Invalid choice")
        sys.exit(1)

def save_data_to_file(packet_list):
    if not packet_list:
        print("No packets to save")
        return
    
    filename = input("Enter the filename to save the data (e.g., data.csv): ")
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['src_ip', 'dst_ip', 'protocol', 'length']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for packet in packet_list:
            writer.writerow(packet)
    print(f"Data saved to {filename}")

def visualize_data(packet_list):
    if not packet_list:
        print("No packets to display")
        return
    
    src_ips = [pkt['src_ip'] for pkt in packet_list]
    dst_ips = [pkt['dst_ip'] for pkt in packet_list]
    
    src_ip_counts = Counter(src_ips)
    dst_ip_counts = Counter(dst_ips)
    
    # Plot source IP addresses
    plt.figure(figsize=(10, 5))
    plt.bar(src_ip_counts.keys(), src_ip_counts.values())
    plt.title('Source IP Addresses')
    plt.xlabel('IP Address')
    plt.ylabel('Count')
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.show()

    # Plot destination IP addresses
    plt.figure(figsize=(10, 5))
    plt.bar(dst_ip_counts.keys(), dst_ip_counts.values())
    plt.title('Destination IP Addresses')
    plt.xlabel('IP Address')
    plt.ylabel('Count')
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.show()

def start_sniffing(interface):
    if not is_root():
        print("This program needs to be run as root.")
        sys.exit(1)

    print(f"Sniffing on interface {interface}...")
    packets = scapy.sniff(iface=interface, count=100, prn=process_packet)
    print("Sniffing completed")
    save_data_to_file(packet_list)
    
    print("Do you want to visualize the data or exit?")
    print("1. Visualize Data")
    print("2. Exit")
    choice = input("Enter your choice (1/2): ")
    if choice == '1':
        visualize_data(packet_list)
    elif choice == '2':
        sys.exit(0)
    else:
        print("Invalid choice")
        sys.exit(1)

packet_list = []

def process_packet(packet):
    if packet.haslayer(scapy.IP):
        ip_src = packet[scapy.IP].src
        ip_dst = packet[scapy.IP].dst
        protocol = packet[scapy.IP].proto
        length = len(packet)
        print(f"IP Src: {ip_src} -> IP Dst: {ip_dst} | Protocol: {protocol} | Length: {length} bytes")
        packet_list.append({
            'src_ip': ip_src,
            'dst_ip': ip_dst,
            'protocol': protocol,
            'length': length
        })

if __name__ == "__main__":
    display_banner()
    interface = select_interface()
    start_sniffing(interface)
